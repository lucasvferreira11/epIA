package cruzamentos;

import algoritmo.Individuo;

public interface ICruzamento {

	public Individuo[] cruza(Individuo i1, Individuo I2);
	
}
